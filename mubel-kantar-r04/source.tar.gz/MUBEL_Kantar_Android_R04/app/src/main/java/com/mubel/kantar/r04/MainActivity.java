package com.mubel.kantar.r04;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.ConsumerIrManager;
import android.net.*;
import android.os.*;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.io.InputStream;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public final class MainActivity extends Activity {
    private static final int REQ_BT = 41;
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private final int NAVY=Color.rgb(17,43,74), GOLD=Color.rgb(176,141,87), IVORY=Color.rgb(246,242,233), GREEN=Color.rgb(20,130,80), RED=Color.rgb(175,35,30);

    private TextView weight, stable, status, raw, hw;
    private EditText ip, port;
    private BluetoothAdapter bt;
    private BluetoothLeScanner bleScanner;
    private ScanCallback bleCallback;
    private BroadcastReceiver btReceiver;
    private BluetoothSocket btSocket;
    private BluetoothGatt gatt;
    private Socket tcpSocket;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newCachedThreadPool();
    private final ExecutorService scanPool = Executors.newFixedThreadPool(24);
    private final LinkedHashMap<String,Candidate> candidates = new LinkedHashMap<>();
    private final StringBuilder rawLog = new StringBuilder();
    private final ScaleParser parser = new ScaleParser();
    private volatile boolean alive = true;
    private String currentSource = "-";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            BluetoothManager bm = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
            bt = bm == null ? null : bm.getAdapter();
        } catch (Throwable t) { bt = null; }
        buildUi();
        refreshHardware();
        setStatus("R04 hazır • Önce DONANIM TESTİ veya AUTO TARA", NAVY);
    }

    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private TextView tv(String s,int sp,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setPadding(dp(8),dp(6),dp(8),dp(6));if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button btn(String s, View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(14);b.setOnClickListener(l);return b;}
    private EditText edit(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setSingleLine(true);e.setPadding(dp(9),dp(8),dp(9),dp(8));return e;}
    private void gap(LinearLayout r,int h){View v=new View(this);r.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private TextView section(String s){TextView t=tv(s,16,true,NAVY);t.setPadding(dp(4),dp(12),dp(4),dp(5));return t;}

    private void buildUi(){
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.setBackgroundColor(IVORY);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(12),dp(12),dp(30));sv.addView(root);

        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);head.setPadding(dp(12),dp(10),dp(12),dp(10));head.setBackgroundColor(NAVY);
        head.addView(tv("MUBEL KANTAR",29,true,Color.WHITE));
        head.addView(tv("UNIVERSAL 2.10.9-R04 • STABIL AÇILIŞ TESTLİ",12,true,Color.rgb(230,218,194)));
        root.addView(head);gap(root,8);

        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),dp(10),dp(10),dp(10));box.setBackgroundColor(Color.WHITE);
        TextView model=tv("NECKLIFE OCS-A • 5000 kg • d=2 kg",13,true,NAVY);box.addView(model);
        weight=tv("0 kg",66,true,NAVY);weight.setGravity(Gravity.CENTER);weight.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);box.addView(weight,new LinearLayout.LayoutParams(-1,dp(115)));
        stable=tv("○ VERİ BEKLENİYOR",19,true,GOLD);stable.setGravity(Gravity.CENTER);box.addView(stable);
        status=tv("Başlatılıyor…",13,true,NAVY);box.addView(status);
        root.addView(box);

        root.addView(section("1 • TELEFON / KANTAR DONANIM TESTİ"));
        hw=tv("Kontrol ediliyor…",13,false,NAVY);hw.setBackgroundColor(Color.WHITE);root.addView(hw);
        LinearLayout r0=new LinearLayout(this);r0.setOrientation(LinearLayout.HORIZONTAL);
        r0.addView(btn("Donanımı Yenile",v->refreshHardware()),new LinearLayout.LayoutParams(0,-2,1));
        r0.addView(btn("IR Kontrol",v->irCheck()),new LinearLayout.LayoutParams(0,-2,1));root.addView(r0);

        root.addView(section("2 • AUTO TARA — BLUETOOTH + BLE + Wi‑Fi"));
        Button auto=btn("⚡ AUTO TARA — TÜM KANALLAR",v->startAutoScan());auto.setTextSize(16);root.addView(auto);
        LinearLayout r1=new LinearLayout(this);r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(btn("Bluetooth / BLE",v->startBtScanOnly()),new LinearLayout.LayoutParams(0,-2,1));
        r1.addView(btn("Wi‑Fi / LAN",v->startLanOnly()),new LinearLayout.LayoutParams(0,-2,1));root.addView(r1);

        LinearLayout net=new LinearLayout(this);net.setOrientation(LinearLayout.HORIZONTAL);
        ip=edit("Kantar IP","192.168.1.200");port=edit("Port","8899");port.setInputType(InputType.TYPE_CLASS_NUMBER);
        net.addView(ip,new LinearLayout.LayoutParams(0,-2,2));net.addView(port,new LinearLayout.LayoutParams(0,-2,1));root.addView(net);
        root.addView(btn("Wi‑Fi / TCP Manuel Bağlan",v->{try{connectTcp(ip.getText().toString().trim(),Integer.parseInt(port.getText().toString().trim()));}catch(Exception e){toast("IP/port kontrol edin");}}));
        root.addView(btn("Bağlantıyı Kes",v->disconnectAll()));

        root.addView(section("3 • CANLI HAM VERİ / PROTOKOL"));
        raw=tv("Henüz veri yok.\n\nNot: OCS-A'da IR kumanda bulunması, ağırlık verisinin IR ile telefona gönderildiği anlamına gelmez. R04 gerçek Bluetooth/BLE/TCP verisini yakalamaya çalışır.",11,false,Color.DKGRAY);
        raw.setTypeface(Typeface.MONOSPACE);raw.setTextIsSelectable(true);raw.setBackgroundColor(Color.WHITE);root.addView(raw,new LinearLayout.LayoutParams(-1,dp(300)));
        root.addView(btn("Ham Veriyi Temizle",v->{rawLog.setLength(0);raw.setText("Temizlendi.");parser.reset();}));

        TextView foot=tv("MUBEL — Güvenin sade hali\nR04 • com.mubel.kantar.r04",12,true,NAVY);foot.setGravity(Gravity.CENTER);root.addView(foot);
        setContentView(sv);
    }

    private void refreshHardware(){
        StringBuilder s=new StringBuilder();
        boolean btp=bt!=null, bte=btp && safeBtEnabled();
        s.append("Bluetooth: ").append(!btp?"donanım yok":(bte?"AÇIK":"KAPALI")).append("\n");
        s.append("Wi‑Fi IPv4: ").append(wifiIpv4()==null?"yok / bağlı değil":wifiIpv4()).append("\n");
        try{ConsumerIrManager ir=(ConsumerIrManager)getSystemService(CONSUMER_IR_SERVICE);s.append("Kızılötesi IR verici: ").append(ir!=null&&ir.hasIrEmitter()?"VAR":"YOK");}catch(Throwable t){s.append("Kızılötesi IR verici: okunamadı");}
        hw.setText(s.toString());
    }
    private boolean safeBtEnabled(){try{return bt!=null&&bt.isEnabled();}catch(Throwable t){return false;}}
    private void irCheck(){
        try{ConsumerIrManager ir=(ConsumerIrManager)getSystemService(CONSUMER_IR_SERVICE);if(ir!=null&&ir.hasIrEmitter()){ConsumerIrManager.CarrierFrequencyRange[] rs=ir.getCarrierFrequencies();StringBuilder s=new StringBuilder("Telefonda IR verici VAR.\n");if(rs!=null)for(ConsumerIrManager.CarrierFrequencyRange r:rs)s.append(r.getMinFrequency()).append("-").append(r.getMaxFrequency()).append(" Hz\n");s.append("\nNECKLIFE kumanda pulse kodu doğrulanmadan ZERO/TARE/HOLD gönderilmeyecek.");dialog("IR HAZIR",s.toString());}else dialog("IR","Telefonda Android Consumer IR vericisi görünmüyor.");}catch(Throwable t){dialog("IR hata",t.toString());}
    }

    private boolean hasBtPerms(){if(Build.VERSION.SDK_INT<31)return true;return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
    private void askBtPerms(){if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);else if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_BT);}
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g);if(req==REQ_BT){setStatus("Bluetooth izin sonucu alındı • AUTO TARA'ya tekrar bas",NAVY);refreshHardware();}}

    private void startAutoScan(){
        if(bt!=null&&!hasBtPerms()){askBtPerms();toast("İzni verip AUTO TARA'ya tekrar basın");return;}
        candidates.clear();stopScanning();setStatus("AUTO TARA başladı…",NAVY);addBonded();startClassicDiscovery();startBleScan();startLanScan();ui.postDelayed(()->publish("AUTO TARA tamamlandı"),8000);
    }
    private void startBtScanOnly(){if(bt!=null&&!hasBtPerms()){askBtPerms();return;}candidates.clear();stopScanning();addBonded();startClassicDiscovery();startBleScan();setStatus("Bluetooth + BLE taranıyor…",NAVY);ui.postDelayed(()->publish("Bluetooth taraması tamamlandı"),6500);}
    private void startLanOnly(){candidates.clear();startLanScan();ui.postDelayed(()->publish("Wi‑Fi/LAN taraması tamamlandı"),6500);}

    private synchronized void putCandidate(Candidate c){candidates.put(c.key(),c);}
    private void addBonded(){if(bt==null||!hasBtPerms())return;try{Set<BluetoothDevice> ds=bt.getBondedDevices();if(ds!=null)for(BluetoothDevice d:ds)putCandidate(new Candidate("BT Classic",safeName(d),d.getAddress(),d,0));}catch(Throwable t){append("Bonded hata: "+t);}}
    private String safeName(BluetoothDevice d){try{String n=d.getName();return n==null||n.trim().isEmpty()?"(isimsiz Bluetooth)":n;}catch(Throwable t){return "(Bluetooth cihazı)";}}

    private void startClassicDiscovery(){if(bt==null||!safeBtEnabled()||!hasBtPerms())return;try{
        btReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){BluetoothDevice d=Build.VERSION.SDK_INT>=33?i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE,BluetoothDevice.class):i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);if(d!=null)putCandidate(new Candidate("BT Classic",safeName(d),d.getAddress(),d,0));}}};
        IntentFilter f=new IntentFilter(BluetoothDevice.ACTION_FOUND);if(Build.VERSION.SDK_INT>=33)registerReceiver(btReceiver,f,Context.RECEIVER_EXPORTED);else registerReceiver(btReceiver,f);if(bt.isDiscovering())bt.cancelDiscovery();bt.startDiscovery();
    }catch(Throwable t){append("Classic tarama hata: "+t);}}

    private void startBleScan(){if(bt==null||!safeBtEnabled()||!hasBtPerms())return;try{bleScanner=bt.getBluetoothLeScanner();if(bleScanner==null)return;bleCallback=new ScanCallback(){@Override public void onScanResult(int type,ScanResult r){BluetoothDevice d=r.getDevice();putCandidate(new Candidate("BLE",safeName(d),d.getAddress(),d,0));}};bleScanner.startScan(bleCallback);ui.postDelayed(()->{try{if(bleScanner!=null&&bleCallback!=null)bleScanner.stopScan(bleCallback);}catch(Throwable ignored){}},6000);}catch(Throwable t){append("BLE tarama hata: "+t);}}

    private void startLanScan(){String local=wifiIpv4();if(local==null){setStatus("Wi‑Fi ağına bağlı değil / IPv4 yok",RED);return;}int p=local.lastIndexOf('.');if(p<0)return;String prefix=local.substring(0,p+1);int[] ports={23,502,1001,2000,4001,5000,6000,8080,8766,8888,8899,9000,9100,10001};setStatus("LAN taranıyor: "+prefix+"1-254",NAVY);for(int h=1;h<=254;h++){final String host=prefix+h;if(host.equals(local))continue;scanPool.submit(()->{for(int po:ports){if(!alive)return;try(Socket s=new Socket()){s.connect(new InetSocketAddress(host,po),120);putCandidate(new Candidate("Wi‑Fi TCP",host,host,null,po));return;}catch(Exception ignored){}}});}}

    private void publish(String title){stopScanning();ArrayList<Candidate> xs; synchronized(this){xs=new ArrayList<>(candidates.values());}if(xs.isEmpty()){dialog(title,"Kablosuz veri cihazı bulunamadı.\n\nBu, uygulamanın açılmadığı anlamına gelmez. OCS-A varyantında Bluetooth/Wi‑Fi veri modülü yoksa cihaz görünmez. IR kumanda ayrı bir kanaldır.");return;}String[] a=new String[xs.size()];for(int i=0;i<a.length;i++)a[i]=xs.get(i).toString();new AlertDialog.Builder(this).setTitle(title+" • "+a.length+" aday").setItems(a,(d,w)->connect(xs.get(w))).setNegativeButton("Kapat",null).show();}

    private void connect(Candidate c){currentSource=c.type+" "+c.name;if(c.type.equals("BT Classic"))connectClassic(c.dev);else if(c.type.equals("BLE"))connectBle(c.dev);else connectTcp(c.address,c.port);}
    private void connectClassic(BluetoothDevice d){if(d==null)return;io.submit(()->{disconnectData();try{if(bt!=null&&bt.isDiscovering())bt.cancelDiscovery();setStatus("BT bağlanıyor: "+safeName(d),NAVY);BluetoothSocket s=d.createRfcommSocketToServiceRecord(SPP);s.connect();btSocket=s;setStatus("BAĞLI • Bluetooth Classic • "+safeName(d),GREEN);readStream(s.getInputStream(),"BT "+safeName(d));}catch(Throwable t){setStatus("BT hata: "+shortErr(t),RED);}});}
    private void connectBle(BluetoothDevice d){if(d==null)return;disconnectData();setStatus("BLE bağlanıyor: "+safeName(d),NAVY);try{gatt=d.connectGatt(this,false,new BluetoothGattCallback(){@Override public void onConnectionStateChange(BluetoothGatt g,int st,int state){if(state==BluetoothProfile.STATE_CONNECTED){setStatus("BLE bağlı • servis aranıyor",GREEN);g.discoverServices();}else if(state==BluetoothProfile.STATE_DISCONNECTED)setStatus("BLE bağlantısı kesildi • "+st,RED);}@Override public void onServicesDiscovered(BluetoothGatt g,int st){BluetoothGattCharacteristic best=null;for(BluetoothGattService s:g.getServices())for(BluetoothGattCharacteristic ch:s.getCharacteristics()){int pr=ch.getProperties();if((pr&BluetoothGattCharacteristic.PROPERTY_NOTIFY)!=0||(pr&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0){best=ch;break;}}if(best==null){setStatus("BLE bağlı ama Notify kanalı yok",RED);return;}g.setCharacteristicNotification(best,true);BluetoothGattDescriptor desc=best.getDescriptor(CCCD);if(desc!=null){byte[] val=(best.getProperties()&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0?BluetoothGattDescriptor.ENABLE_INDICATION_VALUE:BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;if(Build.VERSION.SDK_INT>=33)g.writeDescriptor(desc,val);else{desc.setValue(val);g.writeDescriptor(desc);}}setStatus("BAĞLI • BLE • "+best.getUuid(),GREEN);}@Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic ch,byte[] value){feed(value,"BLE "+safeName(d));}@Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic ch){feed(ch.getValue(),"BLE "+safeName(d));}});}catch(Throwable t){setStatus("BLE hata: "+shortErr(t),RED);}}

    private void connectTcp(String host,int po){if(host.isEmpty()||po<=0)return;io.submit(()->{disconnectData();try{setStatus("TCP bağlanıyor: "+host+":"+po,NAVY);Socket s=new Socket();s.connect(new InetSocketAddress(host,po),4000);s.setTcpNoDelay(true);tcpSocket=s;setStatus("BAĞLI • Wi‑Fi TCP • "+host+":"+po,GREEN);readStream(s.getInputStream(),"TCP "+host+":"+po);}catch(Throwable t){setStatus("TCP hata: "+shortErr(t),RED);}});}
    private void readStream(InputStream in,String src){byte[] b=new byte[1024];try{while(alive){int n=in.read(b);if(n<0)break;if(n>0)feed(Arrays.copyOf(b,n),src);}}catch(Throwable t){if(alive)setStatus(src+" okuma kesildi: "+shortErr(t),RED);}}
    private void feed(byte[] data,String src){if(data==null||data.length==0)return;currentSource=src;String txt=new String(data,StandardCharsets.US_ASCII).replace("\r","\\r").replace("\n","\\n");append(src+"\nHEX "+hex(data)+"\nTXT "+txt);ScaleParser.Reading r=parser.feed(data);if(r!=null)ui.post(()->{weight.setText(formatKg(r.kg)+" kg");stable.setText(r.stable?"● STABİL":"○ HAREKETLİ");stable.setTextColor(r.stable?GREEN:GOLD);setStatus("VERİ • "+src+" • "+r.protocol,r.stable?GREEN:NAVY);});}

    private void append(String s){ui.post(()->{rawLog.append(s).append("\n");if(rawLog.length()>16000)rawLog.delete(0,6000);raw.setText(rawLog.toString());});}
    private String hex(byte[] d){StringBuilder s=new StringBuilder();for(byte b:d)s.append(String.format(Locale.US,"%02X ",b));return s.toString().trim();}
    private String formatKg(double v){return Math.abs(v-Math.rint(v))<0.001?String.format(Locale.getDefault(),"%,.0f",v):String.format(Locale.getDefault(),"%,.3f",v);}
    private String shortErr(Throwable t){String m=t.getMessage();return t.getClass().getSimpleName()+(m==null?"":" • "+m);}
    private void setStatus(String s,int color){ui.post(()->{status.setText(s);status.setTextColor(color);});}
    private void toast(String s){ui.post(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private void dialog(String title,String msg){ui.post(()->{if(isFinishing())return;new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("Tamam",null).show();});}

    private String wifiIpv4(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);if(cm==null)return null;for(Network n:cm.getAllNetworks()){NetworkCapabilities nc=cm.getNetworkCapabilities(n);if(nc==null||!nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))continue;LinkProperties lp=cm.getLinkProperties(n);if(lp==null)continue;for(LinkAddress la:lp.getLinkAddresses())if(la.getAddress() instanceof Inet4Address&&!la.getAddress().isLoopbackAddress())return la.getAddress().getHostAddress();}}catch(Throwable ignored){}return null;}
    private void stopScanning(){try{if(bt!=null&&bt.isDiscovering()&&hasBtPerms())bt.cancelDiscovery();}catch(Throwable ignored){}try{if(bleScanner!=null&&bleCallback!=null&&hasBtPerms())bleScanner.stopScan(bleCallback);}catch(Throwable ignored){}try{if(btReceiver!=null){unregisterReceiver(btReceiver);btReceiver=null;}}catch(Throwable ignored){}}
    private void disconnectData(){try{if(btSocket!=null)btSocket.close();}catch(Throwable ignored){}btSocket=null;try{if(gatt!=null){gatt.disconnect();gatt.close();}}catch(Throwable ignored){}gatt=null;try{if(tcpSocket!=null)tcpSocket.close();}catch(Throwable ignored){}tcpSocket=null;}
    private void disconnectAll(){stopScanning();disconnectData();setStatus("Bağlantılar kapatıldı",NAVY);}
    @Override protected void onDestroy(){alive=false;disconnectAll();io.shutdownNow();scanPool.shutdownNow();super.onDestroy();}

    private static final class Candidate {final String type,name,address;final BluetoothDevice dev;final int port;Candidate(String t,String n,String a,BluetoothDevice d,int p){type=t;name=n;address=a;dev=d;port=p;}String key(){return type+"|"+address+"|"+port;}public String toString(){return type+" • "+name+"\n"+address+(port>0?":"+port:"");}}

    private static final class ScaleParser {
        static final Pattern P=Pattern.compile("(?i)(?:ST|US|S|U)?\\s*[,; ]*(?:GS|NT|WT|G|N)?\\s*[,;:= ]*([+-]?)\\s*(\\d+(?:[.,]\\d+)?)\\s*(kg|g|lb|lbs|t)?");
        final StringBuilder buf=new StringBuilder();final ArrayDeque<Double> hist=new ArrayDeque<>();long stableSince=0;double division=2.0;
        static final class Reading{final double kg;final boolean stable;final String protocol;Reading(double k,boolean s,String p){kg=k;stable=s;protocol=p;}}
        synchronized Reading feed(byte[] d){String s=new String(d,StandardCharsets.US_ASCII);buf.append(s);if(buf.length()>4096)buf.delete(0,2048);String all=buf.toString();String[] lines=all.split("[\\r\\n\\u0003]+",-1);if(lines.length>1){buf.setLength(0);buf.append(lines[lines.length-1]);for(int i=lines.length-2;i>=0;i--){Reading r=parse(lines[i]);if(r!=null)return r;}}Reading r=parse(s);return r;}
        Reading parse(String s){Matcher m=P.matcher(s);if(!m.find())return null;try{double v=Double.parseDouble(m.group(2).replace(',','.'));if("-".equals(m.group(1)))v=-v;String u=m.group(3);if(u!=null){u=u.toLowerCase(Locale.ROOT);if(u.equals("g"))v/=1000.0;else if(u.equals("lb")||u.equals("lbs"))v*=0.45359237;else if(u.equals("t"))v*=1000.0;}boolean deviceStable=s.toUpperCase(Locale.ROOT).contains("ST");boolean sw=stability(v);return new Reading(v,deviceStable||sw,"GENERIC ASCII");}catch(Throwable t){return null;}}
        boolean stability(double v){hist.addLast(v);while(hist.size()>6)hist.removeFirst();if(hist.size()<5){stableSince=0;return false;}double min=Double.MAX_VALUE,max=-Double.MAX_VALUE;for(double x:hist){min=Math.min(min,x);max=Math.max(max,x);}if(max-min<=division){if(stableSince==0)stableSince=System.currentTimeMillis();return System.currentTimeMillis()-stableSince>=700;}stableSince=0;return false;}
        synchronized void reset(){buf.setLength(0);hist.clear();stableSince=0;}
    }
}
