package com.mubel.kantar.triple;

import android.Manifest;
import android.app.Activity;
import android.app.PrintManager;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.hardware.ConsumerIrManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private WebView web;
    private volatile Socket tcpSocket;
    private volatile BluetoothSocket btSocket;
    private BluetoothGatt bleGatt;
    private BluetoothAdapter btAdapter;
    private Handler main = new Handler(Looper.getMainLooper());
    private ExecutorService io = Executors.newCachedThreadPool();
    private final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQ_BT = 201, REQ_LOGO = 202;
    private final List<BluetoothDevice> discoveredClassic = Collections.synchronizedList(new ArrayList<>());
    private final List<BluetoothDevice> discoveredBle = Collections.synchronizedList(new ArrayList<>());
    private BroadcastReceiver discoveryReceiver;
    private ScanCallback bleScanCallback;
    private volatile boolean stopping = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF101214);
        getWindow().setNavigationBarColor(0xFF101214);
        BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        btAdapter=bm!=null?bm.getAdapter():null;
        setupWeb();
        requestBtPermissionsIfNeeded();
    }

    private void setupWeb(){
        web=new WebView(this);
        WebSettings ws=web.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true);
        ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false); ws.setTextZoom(100);
        if(Build.VERSION.SDK_INT>=21) ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(),"Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasBtPermissions(){
        if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return true;
    }
    private void requestBtPermissionsIfNeeded(){
        if(Build.VERSION.SDK_INT>=31 && !hasBtPermissions()) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
    }

    private void js(String code){ main.post(()->web.evaluateJavascript(code,null)); }
    private String q(String s){ if(s==null)s=""; return "'"+s.replace("\\","\\\\").replace("'","\\'").replace("\r","\\r").replace("\n","\\n")+"'"; }
    private void status(String s,String d){ js("window.MUBEL&&MUBEL.nativeStatus("+q(s)+","+q(d)+")"); }
    private void toast(String s){ js("window.MUBEL&&MUBEL.toast("+q(s)+")"); }
    private void raw(byte[] data){ String b64=Base64.encodeToString(data,Base64.NO_WRAP); js("window.MUBEL&&MUBEL.onRawB64("+q(b64)+")"); }

    public class Bridge {
        @JavascriptInterface public void connect(String host,int port){ connectTcp(host,port); }
        @JavascriptInterface public void disconnect(){ disconnectAll(); }
        @JavascriptInterface public void connectBluetooth(){ startBluetoothAuto(); }
        @JavascriptInterface public void connectIr(){ checkIr(); }
        @JavascriptInterface public void pickLogo(){ main.post(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_LOGO);}); }
        @JavascriptInterface public void printHtml(String html,String mode){ main.post(()->printHtmlNative(html,mode)); }
    }

    private void connectTcp(String host,int port){
        disconnectAll(); stopping=false; status("BAĞLANIYOR",host+":"+port);
        io.submit(()->{
            try{
                Socket s=new Socket(); tcpSocket=s; s.connect(new InetSocketAddress(host,port),5000); s.setKeepAlive(true); s.setTcpNoDelay(true);
                status("BAĞLI","Wi‑Fi / TCP · "+host+":"+port);
                InputStream in=s.getInputStream(); byte[] buf=new byte[1024];
                while(!stopping && !s.isClosed()){ int n=in.read(buf); if(n<0)break; if(n>0)raw(Arrays.copyOf(buf,n)); }
                if(!stopping) status("HATA","TCP bağlantısı kapandı");
            }catch(Exception e){ if(!stopping) status("HATA","TCP: "+safe(e)); }
            finally{ closeTcp(); }
        });
    }

    private void startBluetoothAuto(){
        if(btAdapter==null){ status("HATA","Bu telefonda Bluetooth donanımı yok"); return; }
        if(!hasBtPermissions()){ requestBtPermissionsIfNeeded(); status("BAĞLANIYOR","Bluetooth izni bekleniyor"); return; }
        if(!btAdapter.isEnabled()){ status("HATA","Bluetooth kapalı. Telefondan Bluetooth'u açın."); return; }
        disconnectAll(); stopping=false; discoveredClassic.clear(); discoveredBle.clear();
        status("BAĞLANIYOR","Bluetooth / BLE otomatik taranıyor…");
        try{
            Set<BluetoothDevice> bonded=btAdapter.getBondedDevices(); if(bonded!=null) discoveredClassic.addAll(bonded);
        }catch(Exception ignored){}
        registerClassicDiscovery();
        try{ btAdapter.startDiscovery(); }catch(Exception ignored){}
        startBleScan();
        main.postDelayed(()->{ stopScans(); attemptBluetoothCandidates(); },7000);
    }

    private void registerClassicDiscovery(){
        if(discoveryReceiver!=null)return;
        discoveryReceiver=new BroadcastReceiver(){ @Override public void onReceive(Context c,Intent i){
            if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){
                BluetoothDevice d;
                if(Build.VERSION.SDK_INT>=33) d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE,BluetoothDevice.class); else d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(d!=null && !containsAddr(discoveredClassic,d.getAddress())) discoveredClassic.add(d);
            }
        }};
        IntentFilter f=new IntentFilter(BluetoothDevice.ACTION_FOUND); registerReceiver(discoveryReceiver,f);
    }
    private boolean containsAddr(List<BluetoothDevice> xs,String a){ synchronized(xs){ for(BluetoothDevice d:xs) if(d!=null && Objects.equals(d.getAddress(),a))return true; } return false; }
    private void startBleScan(){
        try{
            BluetoothLeScanner sc=btAdapter.getBluetoothLeScanner(); if(sc==null)return;
            bleScanCallback=new ScanCallback(){ @Override public void onScanResult(int t,ScanResult r){ BluetoothDevice d=r.getDevice(); if(d!=null&&!containsAddr(discoveredBle,d.getAddress())) discoveredBle.add(d); } };
            sc.startScan(bleScanCallback);
        }catch(Exception ignored){}
    }
    private void stopScans(){
        try{ if(btAdapter!=null)btAdapter.cancelDiscovery(); }catch(Exception ignored){}
        try{ if(btAdapter!=null&&btAdapter.getBluetoothLeScanner()!=null&&bleScanCallback!=null)btAdapter.getBluetoothLeScanner().stopScan(bleScanCallback); }catch(Exception ignored){}
        bleScanCallback=null;
    }
    private int score(BluetoothDevice d){
        String n=""; try{ n=d.getName(); }catch(Exception ignored){} if(n==null)n=""; n=n.toLowerCase(Locale.ROOT);
        int s=0; String[] keys={"scale","kantar","ocs","neck","densi","weight","crane","hc-05","hc-06","bt","ble"}; for(String k:keys)if(n.contains(k))s+=10; try{if(d.getBondState()==BluetoothDevice.BOND_BONDED)s+=5;}catch(Exception ignored){} return s;
    }
    private void attemptBluetoothCandidates(){
        ArrayList<BluetoothDevice> classics=new ArrayList<>(discoveredClassic); classics.sort((a,b)->Integer.compare(score(b),score(a)));
        ArrayList<BluetoothDevice> bles=new ArrayList<>(discoveredBle); bles.sort((a,b)->Integer.compare(score(b),score(a)));
        io.submit(()->{
            for(BluetoothDevice d:classics){ if(stopping)return; if(tryClassic(d))return; }
            main.post(()->{ if(!stopping && !bles.isEmpty()) connectBle(bles.get(0)); else if(!stopping) status("HATA","Bluetooth/BLE kantar bulunamadı. Kantar açık ve eşleştirme modunda olmalı."); });
        });
    }
    private boolean tryClassic(BluetoothDevice d){
        BluetoothSocket s=null;
        try{
            String name="Bluetooth cihazı"; try{if(d.getName()!=null)name=d.getName();}catch(Exception ignored){}
            status("BAĞLANIYOR","Bluetooth Classic · "+name);
            try{s=d.createRfcommSocketToServiceRecord(SPP); s.connect();}
            catch(Exception first){ try{if(s!=null)s.close();}catch(Exception ignored){} s=(BluetoothSocket)d.getClass().getMethod("createRfcommSocket",int.class).invoke(d,1); s.connect(); }
            btSocket=s; final String fn=name; status("BAĞLI","Bluetooth Classic / SPP · "+fn);
            InputStream in=s.getInputStream(); byte[] buf=new byte[1024];
            while(!stopping && s.isConnected()){ int n=in.read(buf); if(n<0)break; if(n>0)raw(Arrays.copyOf(buf,n)); }
            return true;
        }catch(Exception e){ try{if(s!=null)s.close();}catch(Exception ignored){} return false; }
    }
    private void connectBle(BluetoothDevice d){
        String name="BLE cihazı"; try{if(d.getName()!=null)name=d.getName();}catch(Exception ignored){} status("BAĞLANIYOR","BLE · "+name);
        bleGatt=d.connectGatt(this,false,new BluetoothGattCallback(){
            @Override public void onConnectionStateChange(BluetoothGatt g,int st,int ns){ if(ns==BluetoothProfile.STATE_CONNECTED){ status("BAĞLANIYOR","BLE bağlandı, servisler okunuyor…"); g.discoverServices(); } else if(ns==BluetoothProfile.STATE_DISCONNECTED && !stopping) status("HATA","BLE bağlantısı kesildi"); }
            @Override public void onServicesDiscovered(BluetoothGatt g,int st){
                BluetoothGattCharacteristic best=null;
                for(BluetoothGattService sv:g.getServices()) for(BluetoothGattCharacteristic c:sv.getCharacteristics()){
                    int p=c.getProperties(); if((p&BluetoothGattCharacteristic.PROPERTY_NOTIFY)!=0 || (p&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0){best=c;break;} }
                if(best==null){ status("HATA","BLE cihazında veri bildirim kanalı bulunamadı"); return; }
                g.setCharacteristicNotification(best,true);
                BluetoothGattDescriptor desc=best.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
                if(desc!=null){ byte[] val=(best.getProperties()&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0?BluetoothGattDescriptor.ENABLE_INDICATION_VALUE:BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; if(Build.VERSION.SDK_INT>=33)g.writeDescriptor(desc,val); else{desc.setValue(val);g.writeDescriptor(desc);} }
                status("BAĞLI","Bluetooth LE / BLE · veri kanalı hazır");
            }
            @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){ if(value!=null)raw(value); }
            @SuppressWarnings("deprecation") @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){ byte[] v=c.getValue(); if(v!=null)raw(v); }
        });
    }

    private void checkIr(){
        try{
            ConsumerIrManager ir=(ConsumerIrManager)getSystemService(CONSUMER_IR_SERVICE);
            if(ir==null || !ir.hasIrEmitter()){ status("HATA","Bu telefonda kızılötesi (IR) verici bulunamadı"); return; }
            status("BAĞLI","Kızılötesi (IR) verici hazır · kumanda kanalı");
            toast("IR hazır. Ağırlık verisi için kantarın IR veri göndermesi gerekir.");
        }catch(SecurityException se){ status("HATA","IR izni engellendi: "+safe(se)); }
        catch(Exception e){ status("HATA","IR: "+safe(e)); }
    }

    private void disconnectAll(){ stopping=true; stopScans(); closeTcp(); closeBt(); closeBle(); status("KAPALI","Bağlantı kesildi"); }
    private void closeTcp(){ try{if(tcpSocket!=null)tcpSocket.close();}catch(Exception ignored){} tcpSocket=null; }
    private void closeBt(){ try{if(btSocket!=null)btSocket.close();}catch(Exception ignored){} btSocket=null; }
    private void closeBle(){ try{if(bleGatt!=null){bleGatt.disconnect();bleGatt.close();}}catch(Exception ignored){} bleGatt=null; }
    private String safe(Exception e){ String m=e.getMessage(); return (m==null||m.trim().isEmpty())?e.getClass().getSimpleName():m; }

    private void printHtmlNative(String html,String mode){
        WebView pv=new WebView(this); pv.getSettings().setJavaScriptEnabled(false); pv.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
        pv.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView v,String u){ PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); pm.print("MUBEL KANTAR "+mode,v.createPrintDocumentAdapter("MUBEL KANTAR"),null); }});
    }

    @Override protected void onActivityResult(int req,int res,Intent data){ super.onActivityResult(req,res,data); if(req==REQ_LOGO&&res==RESULT_OK&&data!=null&&data.getData()!=null){
        try(InputStream in=getContentResolver().openInputStream(data.getData()); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n); String mime=getContentResolver().getType(data.getData()); if(mime==null)mime="image/png"; String du="data:"+mime+";base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP); js("window.MUBEL&&MUBEL.setLogo("+q(du)+")");
        }catch(Exception e){ Toast.makeText(this,"Logo okunamadı",Toast.LENGTH_SHORT).show(); }
    }}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==REQ_BT){ boolean ok=true;for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED)ok=false; if(ok)toast("Bluetooth izinleri hazır"); else toast("Bluetooth izni verilmedi"); } }
    @Override protected void onDestroy(){ disconnectAll(); try{if(discoveryReceiver!=null)unregisterReceiver(discoveryReceiver);}catch(Exception ignored){} io.shutdownNow(); if(web!=null)web.destroy(); super.onDestroy(); }
    @Override public void onBackPressed(){ if(web!=null&&web.canGoBack())web.goBack(); else super.onBackPressed(); }
}
