# MUBEL Kantar Android R01

Bu kaynak proje Android telefon/tablet için üç katmanlı bağlantı mimarisidir:

1. Bluetooth Classic / RFCOMM-SPP
2. Bluetooth LE / GATT Notify
3. Wi-Fi / TCP
4. IR donanım kontrolü (yalnızca komut iletimi için)

## Çok önemli IR gerçeği
Android `ConsumerIrManager` standart API'si IR **vericisini** kontrol eder. Telefonda standart bir IR alıcı API'si yoktur. Dolayısıyla bir kantarın ekrandaki ağırlığını IR uzaktan kumanda kanalından telefona okumak genel çözüm değildir. NECKLIFE OCS-A'daki üretici özelliği de "infrared remote control" olarak geçer. IR, doğrulanmış kodlar bulunduğunda ZERO/TARE/HOLD gibi komutlar için kullanılabilir.

## NECKLIFE başlangıç parametresi
- OCS-A
- Max 5000 kg
- d=2 kg
- Stabilite yedek filtresi: 8 örnek içinde <=2 kg yayılım

## Protokol yaklaşımı
Kantar protokolleri tüm markalarda aynı değildir. R01 ASCII akışlardan yaygın `ST,GS,+001248kg` benzeri formatları otomatik ayıklar. Ham HEX/TXT ekranda tutulur. Yeni model için parser profili eklenebilir.

## Android Studio ile APK
Android Studio'da klasörü açın, SDK 36 kurulu olsun, sonra `Build > Build APK(s)`.

Bu ortamda Android SDK/build-tools bulunmadığı için burada imzalı APK binary'si derlenmedi; proje derlenebilir kaynak olarak hazırlanmıştır.
