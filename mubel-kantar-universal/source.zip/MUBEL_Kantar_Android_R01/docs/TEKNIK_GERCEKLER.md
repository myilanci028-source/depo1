# Teknik gerçekler ve sınırlar

- Hangzhou Tianchen OCS-A ürün sayfası IR remote control özelliğini doğrular.
- Üreticinin servis sayfasında Bluetooth indirmesi vardır; bu, tüm OCS-A ünitelerin Bluetooth'lu olduğunu kanıtlamaz.
- Android ConsumerIrManager `hasIrEmitter`, `getCarrierFrequencies`, `transmit` sunar; genel IR receive API'si değildir.
- Android Bluetooth Classic'te RFCOMM/SPP akış bağlantısı desteklenir.
- BLE'de ağırlık verisi genelde Notify/Indicate characteristic üzerinden gelebilir; UUID üreticiye göre değişir.
- Wi-Fi'de TCP/UDP/HTTP/WebSocket protokolleri üreticiye göre değişebilir.
- En genel çözüm: taşıma katmanı (IR/BT/BLE/Wi-Fi) + protokol sürücüsü + öğrenme/ham veri ekranı.
