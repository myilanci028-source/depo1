package com.mubel.kantar;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.ConsumerIrManager;
import android.os.*;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.io.InputStream;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int NAVY=Color.rgb(17,43,74), GOLD=Color.rgb(176,141,87);
    private TextView weight, status, raw, irState;
    private EditText host, port;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newCachedThreadPool();
    private final String SPP="00001101-0000-1000-8000-00805F9B34FB";
    private BluetoothAdapter bt;
    private BluetoothSocket btSocket;
    private BluetoothGatt gatt;
    private Socket tcpSocket;
    private volatile boolean run=true;
    private ScaleParser parser;

    @Override public void onCreate(Bundle b){ super.onCreate(b); requestPerms(); buildUi(); parser=new ScaleParser(this::onReading); parser.setDivisionKg(2.0); }

    private void requestPerms(){
        if(Build.VERSION.SDK_INT>=31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},10);
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},10);
    }

    private TextView t(String s,int size,boolean bold){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(NAVY); v.setPadding(12,8,12,8); if(bold) v.setTypeface(null,1); return v;
    }
    private Button btn(String s,View.OnClickListener l){ Button b=new Button(this); b.setText(s); b.setOnClickListener(l); return b; }

    private void buildUi(){
        ScrollView sv=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,30); sv.addView(root);
        TextView title=t("MUBEL KANTAR",28,true); title.setTextColor(NAVY); root.addView(title);
        root.addView(t("Kızılötesi • Bluetooth Classic/BLE • Wi‑Fi TCP",14,false));
        status=t("Hazır",14,true); status.setTextColor(GOLD); root.addView(status);
        weight=t("0 kg",64,true); weight.setGravity(Gravity.CENTER); weight.setTextColor(NAVY); root.addView(weight,new LinearLayout.LayoutParams(-1,210));

        LinearLayout modes=new LinearLayout(this); modes.setOrientation(LinearLayout.VERTICAL);
        modes.addView(btn("AUTO TARA: Bluetooth + BLE",v->autoScan()));
        modes.addView(btn("Bluetooth Classic (eşleşmiş cihaz)",v->showClassic()));
        modes.addView(btn("Bluetooth LE (BLE) tara",v->scanBle()));
        root.addView(modes);

        LinearLayout wifi=new LinearLayout(this); wifi.setOrientation(LinearLayout.HORIZONTAL);
        host=new EditText(this); host.setHint("Kantar IP (örn. 192.168.1.200)"); host.setText("192.168.1.200"); wifi.addView(host,new LinearLayout.LayoutParams(0,-2,2));
        port=new EditText(this); port.setHint("Port"); port.setText("8766"); port.setInputType(InputType.TYPE_CLASS_NUMBER); wifi.addView(port,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(wifi); root.addView(btn("Wi‑Fi / TCP BAĞLAN",v->connectTcp()));

        irState=t("IR: kontrol ediliyor…",13,true); root.addView(irState); root.addView(btn("IR DONANIMINI TEST ET",v->testIr()));
        TextView note=t("Not: Android'in standart IR API'si yalnızca VERİCİDİR. IR üzerinden kantardan ağırlık okuyamaz. IR burada ZERO/TARE/HOLD gibi kumanda komutları için, kesin kod profili bulunduğunda kullanılacaktır.",13,false); root.addView(note);

        root.addView(t("HAM VERİ",17,true)); raw=t("Henüz veri yok",11,false); raw.setTextIsSelectable(true); root.addView(raw,new LinearLayout.LayoutParams(-1,300));
        root.addView(btn("BAĞLANTILARI KES",v->disconnectAll()));
        setContentView(sv); updateIrState();
    }

    private void onReading(ScaleParser.Reading r){ ui.post(()->{ weight.setText(String.format(Locale.US,"%.0f kg",r.kg)); status.setText(r.stable?"● STABİL":"○ HAREKETLİ"); appendRaw("PARSE: "+r.raw); }); }
    private void feed(byte[] d,String src){ appendRaw(src+" HEX="+hex(d)+" TXT="+new String(d,StandardCharsets.US_ASCII).replace("\r","\\r").replace("\n","\\n")); parser.feed(d); }
    private void appendRaw(String s){ ui.post(()->{ String cur=raw.getText().toString(); if(cur.length()>12000) cur=cur.substring(cur.length()-8000); raw.setText(cur+"\n"+s); }); }
    private String hex(byte[] a){ StringBuilder s=new StringBuilder(); for(byte b:a)s.append(String.format("%02X ",b)); return s.toString(); }

    private void autoScan(){ status.setText("AUTO tarama başladı…"); showClassic(); scanBle(); }

    private BluetoothAdapter adapter(){ BluetoothManager m=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE); bt=m.getAdapter(); return bt; }
    private boolean btAllowed(){ return Build.VERSION.SDK_INT<31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED; }

    private void showClassic(){
        BluetoothAdapter a=adapter(); if(a==null){ toast("Bluetooth yok"); return; } if(!btAllowed()){ requestPerms(); return; }
        Set<BluetoothDevice> bonded=a.getBondedDevices(); if(bonded==null||bonded.isEmpty()){ toast("Önce kantarı Android Bluetooth ayarından eşleştirin."); return; }
        ArrayList<BluetoothDevice> ds=new ArrayList<>(bonded); String[] names=new String[ds.size()];
        for(int i=0;i<ds.size();i++) names[i]=(ds.get(i).getName()==null?"(isimsiz)":ds.get(i).getName())+"\n"+ds.get(i).getAddress();
        new AlertDialog.Builder(this).setTitle("Bluetooth Classic / SPP").setItems(names,(d,w)->connectClassic(ds.get(w))).show();
    }

    private void connectClassic(BluetoothDevice dev){ io.submit(()->{
        try{ disconnectClassic(); ui.post(()->status.setText("BT bağlanıyor: "+dev.getName()));
            btSocket=dev.createRfcommSocketToServiceRecord(UUID.fromString(SPP)); btSocket.connect(); ui.post(()->status.setText("BT Classic bağlı"));
            InputStream in=btSocket.getInputStream(); byte[] buf=new byte[512]; int n; while(run && btSocket!=null && (n=in.read(buf))>0) feed(Arrays.copyOf(buf,n),"BT");
        }catch(Exception e){ ui.post(()->status.setText("BT hata: "+e.getMessage())); }
    }); }

    private void scanBle(){
        BluetoothAdapter a=adapter(); if(a==null||!a.isEnabled()){ toast("Bluetooth'u açın"); return; }
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){ requestPerms(); return; }
        BluetoothLeScanner sc=a.getBluetoothLeScanner(); if(sc==null){toast("BLE tarayıcı yok");return;}
        LinkedHashMap<String,BluetoothDevice> found=new LinkedHashMap<>(); status.setText("BLE taranıyor…");
        ScanCallback cb=new ScanCallback(){ @Override public void onScanResult(int c,ScanResult r){ BluetoothDevice d=r.getDevice(); found.put(d.getAddress(),d); }};
        sc.startScan(cb); ui.postDelayed(()->{ try{sc.stopScan(cb);}catch(Exception ignored){} showBle(found); },6000);
    }
    private void showBle(LinkedHashMap<String,BluetoothDevice> map){
        if(map.isEmpty()){toast("BLE cihaz bulunamadı");status.setText("BLE bulunamadı");return;}
        ArrayList<BluetoothDevice> ds=new ArrayList<>(map.values()); String[] names=new String[ds.size()];
        for(int i=0;i<ds.size();i++){ String n="(izin sonrası ad görünür)"; try{ if(btAllowed()&&ds.get(i).getName()!=null)n=ds.get(i).getName(); }catch(Exception ignored){} names[i]=n+"\n"+ds.get(i).getAddress(); }
        new AlertDialog.Builder(this).setTitle("BLE cihaz seç").setItems(names,(d,w)->connectBle(ds.get(w))).show();
    }
    private void connectBle(BluetoothDevice d){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPerms();return;}
        if(gatt!=null) try{gatt.close();}catch(Exception ignored){}
        status.setText("BLE bağlanıyor…"); gatt=d.connectGatt(this,false,new BluetoothGattCallback(){
            @Override public void onConnectionStateChange(BluetoothGatt g,int st,int state){ if(state==BluetoothProfile.STATE_CONNECTED){ui.post(()->status.setText("BLE bağlı, servis aranıyor"));g.discoverServices();} else ui.post(()->status.setText("BLE koptu")); }
            @Override public void onServicesDiscovered(BluetoothGatt g,int st){ for(BluetoothGattService s:g.getServices()) for(BluetoothGattCharacteristic c:s.getCharacteristics()) if((c.getProperties()&BluetoothGattCharacteristic.PROPERTY_NOTIFY)!=0 || (c.getProperties()&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0){ g.setCharacteristicNotification(c,true); BluetoothGattDescriptor cccd=c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")); if(cccd!=null){cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); g.writeDescriptor(cccd);} ui.post(()->status.setText("BLE veri kanalı bulundu")); return;} ui.post(()->status.setText("BLE notify kanalı bulunamadı")); }
            @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){ byte[] v=c.getValue(); if(v!=null)feed(v,"BLE"); }
        });
    }

    private void connectTcp(){ final String h=host.getText().toString().trim(); final int p=Integer.parseInt(port.getText().toString().trim()); io.submit(()->{
        try{ disconnectTcp(); ui.post(()->status.setText("Wi‑Fi TCP bağlanıyor…")); tcpSocket=new Socket(); tcpSocket.connect(new InetSocketAddress(h,p),5000); tcpSocket.setSoTimeout(1500); ui.post(()->status.setText("Wi‑Fi TCP bağlı")); InputStream in=tcpSocket.getInputStream(); byte[] b=new byte[1024]; while(run&&tcpSocket!=null){ try{int n=in.read(b); if(n<0)break; if(n>0)feed(Arrays.copyOf(b,n),"TCP");}catch(SocketTimeoutException ignored){} } }
        catch(Exception e){ ui.post(()->status.setText("TCP hata: "+e.getMessage())); }
    }); }

    private void updateIrState(){ ConsumerIrManager ir=(ConsumerIrManager)getSystemService(Context.CONSUMER_IR_SERVICE); boolean ok=ir!=null&&ir.hasIrEmitter(); irState.setText(ok?"IR: Telefonda kızılötesi VERİCİ var":"IR: Telefonda Android uyumlu IR verici yok"); }
    private void testIr(){ ConsumerIrManager ir=(ConsumerIrManager)getSystemService(Context.CONSUMER_IR_SERVICE); if(ir==null||!ir.hasIrEmitter()){toast("Bu telefonda desteklenen IR verici yok");return;} ConsumerIrManager.CarrierFrequencyRange[] r=ir.getCarrierFrequencies(); StringBuilder s=new StringBuilder("IR verici hazır. Frekans aralıkları:\n"); if(r!=null)for(ConsumerIrManager.CarrierFrequencyRange x:r)s.append(x.getMinFrequency()).append("-").append(x.getMaxFrequency()).append(" Hz\n"); s.append("NECKLIFE komut kodu doğrulanmadan ZERO/TARE/HOLD gönderilmeyecek."); new AlertDialog.Builder(this).setTitle("IR TEST").setMessage(s.toString()).setPositiveButton("Tamam",null).show(); }

    private void disconnectClassic(){ try{if(btSocket!=null)btSocket.close();}catch(Exception ignored){} btSocket=null; }
    private void disconnectTcp(){ try{if(tcpSocket!=null)tcpSocket.close();}catch(Exception ignored){} tcpSocket=null; }
    private void disconnectAll(){ disconnectClassic(); disconnectTcp(); try{if(gatt!=null){gatt.disconnect();gatt.close();}}catch(Exception ignored){} gatt=null; status.setText("Bağlantılar kesildi"); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    @Override protected void onDestroy(){ run=false; disconnectAll(); io.shutdownNow(); super.onDestroy(); }
}
