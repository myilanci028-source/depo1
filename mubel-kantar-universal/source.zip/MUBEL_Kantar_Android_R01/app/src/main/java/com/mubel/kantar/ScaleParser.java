package com.mubel.kantar;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ScaleParser {
    public static final class Reading {
        public final double kg;
        public final boolean stable;
        public final String raw;
        public Reading(double kg, boolean stable, String raw) { this.kg=kg; this.stable=stable; this.raw=raw; }
    }

    private final StringBuilder textBuffer = new StringBuilder();
    private final ArrayDeque<Double> recent = new ArrayDeque<>();
    private final Pattern[] patterns = new Pattern[]{
            Pattern.compile("(?i)(?:ST|US|S|U)?\\s*[,; ]*(?:GS|NT|WT|NET|GROSS)?\\s*[,;:= ]*([+-]?\\d+(?:[.,]\\d+)?)\\s*(kg|g|lb|lbs|t)?"),
            Pattern.compile("(?i)(?:WT|WEIGHT|NET|GROSS)\\s*[:=]\\s*([+-]?\\d+(?:[.,]\\d+)?)\\s*(kg|g|lb|lbs|t)?")
    };

    public interface Listener { void onReading(Reading r); }
    private final Listener listener;
    private double divisionKg = 2.0;

    public ScaleParser(Listener l){ listener=l; }
    public void setDivisionKg(double d){ divisionKg=Math.max(0.001,d); }

    public synchronized void feed(byte[] data){
        String s = new String(data, StandardCharsets.US_ASCII);
        textBuffer.append(s);
        if (textBuffer.length()>16384) textBuffer.delete(0,8192);
        String all=textBuffer.toString();
        String[] lines=all.split("[\\r\\n\\u0003]+");
        boolean terminated = all.matches("(?s).*[\\r\\n\\u0003]$");
        int count = terminated ? lines.length : Math.max(0, lines.length-1);
        for(int i=0;i<count;i++) parseLine(lines[i]);
        textBuffer.setLength(0);
        if(!terminated && lines.length>0) textBuffer.append(lines[lines.length-1]);
    }

    private void parseLine(String raw){
        String t=raw.trim(); if(t.isEmpty()) return;
        String up=t.toUpperCase(Locale.ROOT);
        for(Pattern p:patterns){
            Matcher m=p.matcher(t);
            if(m.find()){
                try{
                    double v=Double.parseDouble(m.group(1).replace(',','.'));
                    String unit=m.groupCount()>=2 && m.group(2)!=null ? m.group(2).toLowerCase(Locale.ROOT) : "kg";
                    if(unit.equals("g")) v/=1000.0; else if(unit.equals("lb")||unit.equals("lbs")) v*=0.45359237; else if(unit.equals("t")) v*=1000.0;
                    boolean deviceStable = up.matches(".*(^|[,;\\s])ST([,;\\s]|$).*") || up.contains("STABLE");
                    boolean stable = deviceStable || softwareStable(v);
                    listener.onReading(new Reading(v, stable, t));
                    return;
                }catch(Exception ignored){}
            }
        }
    }

    private boolean softwareStable(double v){
        recent.addLast(v); while(recent.size()>8) recent.removeFirst();
        if(recent.size()<8) return false;
        double min=Double.MAX_VALUE,max=-Double.MAX_VALUE;
        for(double x:recent){ min=Math.min(min,x); max=Math.max(max,x); }
        return (max-min)<=divisionKg;
    }
}
